# speed-limit-grabber-chrome-extension

<b>Submits speed limits.</b>

Stay home, drink a beer and help reduce road rage. Since 2005, Wikispeedia.org has provided speed limit information free of charge for apps, cruise controls, DIY projects. 

1) Install this extension
2) Open maps.google.com
3) Go to street view. 
4) Move around until you see a speed limit sign. (They are everywhere!)
5) Click on the icon in the top corner of your chrome browser..
6) Click the speed limit you see, (this isn't optical character recognition friend)...
7) Click Enter. That's it! Go see your sign on wikispeedia.org
