
// Saves options to chrome.storage
function save_options() {
 
  var likesName  = document.getElementById('likename').value;
  var likesName2  = document.getElementById('likename2').value;
  var likesName3  = document.getElementById('likename3').value;
  var likesName4  = document.getElementById('likename4').value;
  
  //also store it in html5 storage, not chrome storage which i couldnt get working
  localStorage.setItem("likename", likesName);
  localStorage.setItem("likename2", likesName2);
  localStorage.setItem("likename3", likesName3);
  localStorage.setItem("likename4", likesName4);
  
  
  chrome.storage.sync.set({
   
	likesName:  likesName,
	likesName2: likesName2,
	likesName3: likesName3,
	likesName4: likesName4
  }, function() {
    // Update status to let user know options were saved.
    var status = document.getElementById('status');
    status.textContent = chrome.i18n.getMessage("optionsSavedLbl");
    setTimeout(function() {
      status.textContent = '';
    }, 750);
  });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  // Use default value color = 'red' and likesColor = true.
  chrome.storage.sync.get({
 
	likesName: chrome.i18n.getMessage("yourNameTxt"),// 'your name',
	likesName2: chrome.i18n.getMessage("yourEmailTxt"),// 'your email address',
	likesName3: chrome.i18n.getMessage("yourBTCTxt"),// 'your btc number'	
	likesName4: chrome.i18n.getMessage("yourHEYTxt")// 'your hey_tryhere flag'
  }, function(items) {
  
	document.getElementById('likename').value= items.likesName;
	document.getElementById('likename2').value= items.likesName2;
	document.getElementById('likename3').value= items.likesName3;
	
	if (items.likesName4 == "" || items.likesName4 == 'no') {
		document.getElementById('likename4').value= 'no';	
	} else {
		document.getElementById('likename4').value= 'yes';
	}
	
	
  });
}
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click',
    save_options);
document.getElementById('title').innerHTML = chrome.i18n.getMessage("optionsLbl");
document.getElementById('optional').innerHTML = chrome.i18n.getMessage("optionalLbl");
document.getElementById('option-name').innerHTML = chrome.i18n.getMessage("nameLbl");
document.getElementById('option-payment').innerHTML = chrome.i18n.getMessage("getPaidLbl");
document.getElementById('option-email').innerHTML = chrome.i18n.getMessage("emailLbl");
document.getElementById('option-btc').innerHTML = chrome.i18n.getMessage("orBTCLbl");
document.getElementById('option-hey').innerHTML = chrome.i18n.getMessage("orHEYLbl");
document.getElementById('save').innerHTML = chrome.i18n.getMessage("saveLbl");